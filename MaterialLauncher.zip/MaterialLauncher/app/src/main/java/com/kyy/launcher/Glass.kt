package com.kyy.launcher

import android.graphics.Bitmap
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * Liquid Glass в духе iOS 26.
 *
 * Из чего собрано стекло (снизу вверх):
 *  1. копия обоев, вырезанная ровно под плашку, размытая так же, как фон экрана;
 *  2. на Android 13+ — шейдер AGSL: у кромки плашки картинка «загибается» внутрь (преломление, как у линзы)
 *     и чуть расходится по цветам (дисперсия);
 *  3. лёгкая белая подкраска и вертикальный блик;
 *  4. светлая кромка со световым градиентом (ярче по диагонали).
 *
 * Если обои прочитать нельзя (живые обои, нет прав) или Android ниже 12, пункты 1–2 пропускаются,
 * а подкраска делается плотнее, чтобы плашка выглядела матовым стеклом.
 */

/** Копия обоев и сила размытия, которыми пользуются все стеклянные плашки экрана. */
class GlassEnv(val bitmap: Bitmap, val blurPx: Float)

/** null — вне экрана блокировки (например, предпросмотр в настройках): рисуем матовое стекло без обоев. */
val LocalGlass = compositionLocalOf<GlassEnv?> { null }

private const val GLASS_AGSL = """
uniform shader content;
uniform float4 box;       // left, top, width, height плашки в пикселях слоя
uniform float radius;     // радиус скругления, px
uniform float bevel;      // ширина преломляющей кромки, px
uniform float strength;   // насколько кромка «загибает» картинку, px

float sdf(float2 p) {
    float2 c = box.xy + box.zw * 0.5;
    float2 q = abs(p - c) - (box.zw * 0.5 - float2(radius));
    return length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - radius;
}

half4 main(float2 p) {
    float d = sdf(p);
    if (d > 0.0) return content.eval(p);
    float e = 1.0 - clamp(-d / bevel, 0.0, 1.0);
    e = e * e;
    float2 g = float2(sdf(p + float2(1.0, 0.0)) - sdf(p - float2(1.0, 0.0)),
                      sdf(p + float2(0.0, 1.0)) - sdf(p - float2(0.0, 1.0)));
    g = g / max(length(g), 0.0001);
    float2 c = box.xy + box.zw * 0.5;
    float2 uv = c + (p - c) * 0.96 - g * e * strength;
    half4 a = content.eval(uv);
    half4 cr = content.eval(uv - g * e * 2.0);
    half4 cb = content.eval(uv + g * e * 2.0);
    return half4(cr.r, a.g, cb.b, a.a);
}
"""

/** Эффект слоя: размытие, а на Android 13+ ещё и преломление у кромки. */
private fun lensEffect(w: Int, h: Int, m: Int, radiusPx: Float, blurPx: Float, density: Float): RenderEffect? {
    val blur = if (blurPx > 0.5f) android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP) else null
    if (Build.VERSION.SDK_INT < 33) return blur?.asComposeRenderEffect()
    val bevel = min(min(w, h) * 0.42f, 22f * density)
    val sh = RuntimeShader(GLASS_AGSL)
    sh.setFloatUniform("box", m.toFloat(), m.toFloat(), w.toFloat(), h.toFloat())
    sh.setFloatUniform("radius", radiusPx)
    sh.setFloatUniform("bevel", bevel)
    sh.setFloatUniform("strength", bevel * 0.85f)
    val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(sh, "content")
    // createChainEffect(outer, inner): сначала inner (размытие), затем outer (преломление)
    val eff = if (blur != null) android.graphics.RenderEffect.createChainEffect(lens, blur) else lens
    return eff.asComposeRenderEffect()
}

/**
 * Кусок обоев под плашкой. Слой делается чуть больше плашки (запас m), чтобы размытие у кромок видело соседние пиксели,
 * а не прозрачность; лишнее обрезает родитель. Картинка берётся так же, как на фоне: обои по центру, «Crop» на весь экран.
 */
@Composable
private fun BoxScope.GlassLens(env: GlassEnv, pos: Offset, boxSize: IntSize, radiusPx: Float) {
    if (boxSize.width <= 0 || boxSize.height <= 0) return
    val dm = LocalContext.current.resources.displayMetrics
    val density = LocalDensity.current.density
    val img = remember(env.bitmap) { env.bitmap.asImageBitmap() }
    val m = min(env.blurPx * 2f, 160f).roundToInt().coerceAtLeast(2)
    val w = boxSize.width
    val h = boxSize.height
    val effect = remember(w, h, m, radiusPx, env.blurPx, density) { lensEffect(w, h, m, radiusPx, env.blurPx, density) }
    Spacer(
        Modifier
            .align(Alignment.TopStart)
            // сам Spacer размера не занимает (0×0), чтобы не раздувать плашку; рисует он за её границами
            .layout { measurable, _ ->
                val p = measurable.measure(Constraints.fixed(w + 2 * m, h + 2 * m))
                layout(0, 0) { p.place(-m, -m) }
            }
            .graphicsLayer { renderEffect = effect }
            .drawBehind {
                val sw = dm.widthPixels.toFloat()
                val sh = dm.heightPixels.toFloat()
                val bw = img.width.toFloat()
                val bh = img.height.toFloat()
                val k = max(sw / bw, sh / bh)
                val ox = (sw - bw * k) / 2f
                val oy = (sh - bh * k) / 2f
                val l = (pos.x - m - ox) / k
                val t = (pos.y - m - oy) / k
                drawImage(
                    img,
                    srcOffset = IntOffset(l.roundToInt(), t.roundToInt()),
                    srcSize = IntSize((this.size.width / k).roundToInt().coerceAtLeast(1), (this.size.height / k).roundToInt().coerceAtLeast(1)),
                    dstSize = IntSize(this.size.width.roundToInt(), this.size.height.roundToInt()),
                    filterQuality = FilterQuality.Medium
                )
            }
    )
}

/**
 * Стеклянная плашка. [cornerRadius] = null — «таблетка» (радиус = половина меньшей стороны).
 * [tint] — цвет подкраски (для включённой кнопки передают акцент темы).
 */
@Composable
fun GlassSurface(
    shape: Shape,
    modifier: Modifier = Modifier,
    cornerRadius: Dp? = null,
    tint: Color = Color.White,
    tintAlpha: Float = 0.12f,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit
) {
    val env = LocalGlass.current
    val density = LocalDensity.current.density
    var pos by remember { mutableStateOf(Offset.Zero) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val lens = env != null && Build.VERSION.SDK_INT >= 31
    Box(
        modifier
            .onGloballyPositioned { pos = it.positionInWindow(); boxSize = it.size }
            .clip(shape),
        contentAlignment = contentAlignment
    ) {
        if (lens && env != null) {
            val r = if (cornerRadius != null) cornerRadius.value * density else min(boxSize.width, boxSize.height) / 2f
            GlassLens(env, pos, boxSize, r)
        }
        // подкраска: на настоящем размытии лёгкая, на «матовом» запасном варианте плотнее
        Box(Modifier.matchParentSize().background(tint.copy(alpha = (if (lens) tintAlpha else tintAlpha * 2.2f + 0.04f).coerceAtMost(0.9f))))
        // блик: свет сверху, лёгкая тень снизу
        Box(
            Modifier.matchParentSize().background(
                Brush.verticalGradient(listOf(Color.White.copy(.22f), Color.Transparent, Color.Black.copy(.07f)))
            )
        )
        // кромка: светится по диагонали, как у стекла со скошенным краем
        Box(
            Modifier.matchParentSize().border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(.9f), Color.White.copy(.08f), Color.White.copy(.3f), Color.White.copy(.7f))),
                shape
            )
        )
        content()
    }
}
